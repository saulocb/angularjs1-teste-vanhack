
	angular.module('common', ['ui.bootstrap']).
						  
	              //   *************SERVICE****************
	factory('modalFactory', function($uibModal) {
		return {
		  open: function(size, template, controller, params) {
			return $uibModal.open({
			  animation: true,
			  templateUrl: template,
			  controller: controller,
				size: size,				
			  resolve: {
				params: function() {
				  return params;
				}
			  }
			});
		  }
		};
		});            //   *************controlls**************** 
	
	
		
			
