angular.module('app').config(['$stateProvider', function($stateProvider){
    $stateProvider.
       state('user',{
           url: '/user',
           templateUrl: '../modules/user/views/user.html',
           controller: 'userController',  
    }).state('home',{
        url: '/home',
        templateUrl: '../modules/home.html',
        controller: 'MainController'
 }).state('details',{
    url: 'details/:userId', 
    templateUrl: '../modules/user/views/details.html',
    controller: 'userDelailsController'
}).state('/',{
    url: '/home',
    templateUrl: '../modules/home.html',
    controller: 'MainController'
})   
}])
