angular.module('app')

.directive('dicUser', function(userService,$location,$state,$rootScope,$uibModal,modalFactory) {
    return {
        restrict: 'AE',
        scope: {
            paramUser: '=info'
          },
        templateUrl: 'user/views/userDirect.html',
        link: function(scope, element, attr) {  
          // ************Modal**********         
          scope.open = function(idUser) {
            modalFactory.open('lg', 'user/views/_modalUser.html','modalUser', {searchTerm: idUser});  
          }; 
          
          // ************check-list**********            
          scope.checked_list =  $rootScope.checked_list;
          scope.toggleCheck = function (paramId) {
            if ($rootScope.checked_list.indexOf(paramId) === -1) {              
              $rootScope.checked_list.push(paramId)                            
            } else {
              $rootScope.checked_list.splice($rootScope.checked_list.indexOf(paramId), 1);
            }
        };
        }        
    };

  });