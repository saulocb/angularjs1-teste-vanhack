angular.module("user").controller("userDelailsController",function($scope,$stateParams,userService,$rootScope,$state,modalFactory){
    $scope.userId = $stateParams.userId;   
    $scope.user =  "";


userService.getAllUser().success(function(data) {
        $scope.user =  data.find(x => x.id == $scope.userId);            
      })
      .error(function(err) {
          alert("error interno del sistema"); 
});

$scope.edit =  function(){    
    $.each($rootScope.listUserGl,function(i,v){       
        if (v.id == $scope.userId) {
          v.firstName = $scope.user.firstName;
          v.dateOfBirth = $scope.user.dateOfBirth != null ? $scope.user.dateOfBirth: v.dateOfBirth;
          alert("changed successfully..");
          $state.go('user');
          return false;          
        }
      }); 
}

})