angular.module('common').
controller('modalUser', function($scope, $rootScope,$uibModalInstance, params) {
    $scope.user = null;
    $scope.UserId = params.searchTerm; 
    $scope.user  = $rootScope.listUserGl.find(x=>x.id ==  $scope.UserId);    
                              
    $scope.ok = function() {
    $uibModalInstance.close($scope.searchTerm);
    };

    $scope.cancel = function() {
    $uibModalInstance.dismiss('cancel');
    };

    $scope.calculateAge =  function(){
    var birthday = new Date($scope.user.dateOfBirth);
    $scope.age =  calculate_age(birthday.getMonth(),birthday.getDay(),birthday.getFullYear())              
    }
    function calculate_age(birth_month,birth_day,birth_year)
    {
        today_date = new Date();
        today_year = today_date.getFullYear();
        today_month = today_date.getMonth();
        today_day = today_date.getDate();
        age = today_year - birth_year;
    
        if ( today_month < (birth_month - 1))
        {
            age--;
        }
        if (((birth_month - 1) == today_month) && (today_day < birth_day))
        {
            age--;
        }
        return age;
    }
    $scope.calculateAge();  


    $scope.delete =  function(userId){        
        var index = $rootScope.listUserGl.findIndex(x=>x.id ==  userId );
        var indexData =   $rootScope.data.findIndex(x=>x.id ==  userId );
        var userName =  $rootScope.listUserGl[index].firstName;
        $rootScope.listUserGl.splice(index, 1);  
        $rootScope.data.splice(indexData, 1);
        $rootScope.noOfPages = Math.ceil( $rootScope.listUserGl.length / $scope.numPerPage);
        alert('User: ' + userName + ' has been deleted successfully');        
        $uibModalInstance.close($scope.searchTerm);     
                                                
    }

})