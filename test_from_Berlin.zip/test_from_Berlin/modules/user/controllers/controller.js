angular.module("user").controller("userController",function($scope,userService,$rootScope){
  
// ************pagination**********
$rootScope.listUserGl;  
$rootScope.data;   
$rootScope.numPerPage = 10;
$rootScope.noOfPages = Math.ceil( $rootScope.listUserGl.length / $scope.numPerPage);
$scope.currentPage = 1;

function get(offset, limit) {
  return $rootScope.listUserGl.slice( offset, offset+limit );
}
$scope.setPage = function () {
  $rootScope.data = get( ($scope.currentPage - 1) * $scope.numPerPage, $scope.numPerPage );
};
$scope.$watch( 'currentPage', $scope.setPage );
// ************check-list**********
$rootScope.checked_list = [];
$scope.checkedValid = $rootScope.checked_list.length > 0 ? false: true; 
$scope.$watch("checked_list.length", function(){  
$scope.checkedValid =  $rootScope.checked_list.length > 0 ? false: true; 
})

// ************Download CSV**********
$scope.Download =  function(){
  str =  ConvertToCSV($rootScope.listUserGl);
  var csvContent = "data:text/csv;charset=utf-8,";
  var encodedUri = encodeURI(csvContent);  
  downloadFileCSV("fileUser.csv", str)       
}

function downloadFileCSV(filename, text) {
  var element = document.createElement('a');
  element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
  element.setAttribute('download', filename);

  element.style.display = 'none';
  document.body.appendChild(element);

  element.click();

  document.body.removeChild(element);
}

function ConvertToCSV(objArray) {
  var csvContent = "data:text/csv;charset=utf-8,";
  var array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
  var str = '';

  for (var i = 0; i < array.length; i++) {
      var line = '';
      for (var index in array[i]) {
          if (line != '') line += ';'

          line += array[i][index];
      }

      str += line + '\r\n';
  }

  return str;
}
// ************delete**********
  $scope.delete =  function(){    
    $rootScope.checked_list.forEach(function(element) {
    var index = $rootScope.listUserGl.findIndex(x=>x.id ==  element );
    var indexData =   $rootScope.data.findIndex(x=>x.id ==  element );
    $rootScope.listUserGl.splice(index, 1);  
    $rootScope.data.splice(indexData, 1);    
   }, $rootScope.checked_list = []);
  //  updates noOfPages from pagination
   $rootScope.noOfPages = Math.ceil( $rootScope.listUserGl.length / 10);
  }

}).controller("teste", function(){})

