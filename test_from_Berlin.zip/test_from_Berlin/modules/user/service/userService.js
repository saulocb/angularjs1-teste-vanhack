angular.module("user").service  ('userService', ['$http', function($http) {
    var listUser = []

this.getAllUser =  function(){
    getUserData();
    return $http.get('../data/users.json');
};  

function getUserData(){
    $http.get('../data/users.json').success(function(data) {
        this.listUser =  data;             
    })
    .error(function(err) {
        alert("internal system error"); 
    });
}


}])