angular.module('app',[
    'ui.router',    
    'ui.bootstrap',
    'common',
    'user'
    
]).run(function($rootScope,userService) {
    $rootScope.listUserGl= null;
    GetUser();
    
    function GetUser(){
        userService.getAllUser().success(function(data) {  
            $rootScope.listUserGl =data;              
          })
          .error(function(err) {
              alert("internal system error"); 
          });
    }
   
    
});