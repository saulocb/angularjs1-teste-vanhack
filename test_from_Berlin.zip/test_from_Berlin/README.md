# Newsletter2go fe-test

#installation

1) open a command block inside the root folder
2) run the command 'http-server'
3) open the url in path /modules;     ex: http://169.254.79.0:8080/modules    





 
 
